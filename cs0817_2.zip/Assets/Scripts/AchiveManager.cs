using System;
using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public class AchiveManager : MonoBehaviour
{
    public GameObject[] lockCharacter;
    public GameObject[] unlockCharacter;
    public GameObject uiNotice;
    enum Achieve { UnLockBlackCat, UnLockPurpleCat }
    Achieve[] achives;
    WaitForSecondsRealtime wait;

    void Awake()
    {
        achives = (Achieve[])Enum.GetValues(typeof(Achieve));
        wait = new WaitForSecondsRealtime(5);
        if (!PlayerPrefs.HasKey("MyData"))
        {
            Init();
        }

    }

    void Init()
    {
        PlayerPrefs.SetInt("MyData", 1);

        foreach (Achieve achieve in achives)
        {
            PlayerPrefs.SetInt(achieve.ToString(), 0); //�ر� �Ǹ� 1, �ƴϸ� 0
        }
    }

    void Start()
    {
        UnlockCharacter();
    }


    void UnlockCharacter()
    {
        for (int index = 0; index < lockCharacter.Length; index++)
        {
            string achiveName = achives[index].ToString();
            bool isUnlock = PlayerPrefs.GetInt(achiveName) == 1;
            lockCharacter[index].SetActive(!isUnlock);
            unlockCharacter[index].SetActive(isUnlock);
        }


    }

    void LateUpdate()
    {
        foreach (Achieve achieve in achives)
        {
            CheckAchive(achieve);
        }

    }
    void CheckAchive(Achieve achieve)
    {    
        
        
            bool isAchive = false;

            switch (achieve)
            {
                case Achieve.UnLockBlackCat:
                    isAchive = GameManager.instance.kill >= 100; //100ų �̻��̸� �����޼� -������ �ر� ���� 
                    break;
                case Achieve.UnLockPurpleCat:
                    isAchive = GameManager.instance.gameTime == GameManager.instance.maxGameTime; //������ ����-����� �ر� ���� 
                    break;

            }

            if(isAchive && PlayerPrefs.GetInt(achieve.ToString()) == 0)
            {
                PlayerPrefs.SetInt(achieve.ToString(), 1); //true
            for (int index = 0; index < uiNotice.transform.childCount; index++)
            {
                bool isActive = index == (int)achieve;
                uiNotice.transform.GetChild(index).gameObject.SetActive(isActive);
            }

                StartCoroutine(NoticeRoutine());

            }
        
    }

    IEnumerator NoticeRoutine()
    {
        uiNotice.SetActive(true);

        AudioManager.instance.PlaySfx(AudioManager.Sfx.LevelUp);

        yield return wait;
        uiNotice.SetActive(false);
    }
  
}