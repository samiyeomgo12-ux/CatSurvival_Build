using System.Collections;
using UnityEngine;

public class DropItem : MonoBehaviour
{
    public enum ItemType { Heal, Magnet }

    [Header("Type")] public ItemType type = ItemType.Heal;
    [Header("Heal")] public float healAmount = 100f;   // Ǯ��
    [Header("Magnet")] public float magnetRadius = 10f; // �ڼ� �ݰ�
    public float magnetDuration = 5f;                   // �ڼ� ���� �ð�
    [Header("Common")] public float autoDisableDelay = 0.05f;
    public bool playSfx = true;

    Collider2D col; bool picked;

    void Awake() { col = GetComponent<Collider2D>(); if (col) col.isTrigger = true; }
    void OnEnable() { picked = false; if (col) col.enabled = true; }

    public void InitHeal(float amount) { type = ItemType.Heal; healAmount = amount; picked = false; if (col) col.enabled = true; }
    public void InitMagnet(float radius, float duration) { type = ItemType.Magnet; magnetRadius = radius; magnetDuration = duration; picked = false; if (col) col.enabled = true; }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (picked || !other.CompareTag("Player")) return;
        picked = true; if (col) col.enabled = false;

        switch (type)
        {
            case ItemType.Heal:
                GameManager.instance.HealFull();
                if (playSfx && GameManager.instance.isLive)
                    AudioManager.instance.PlaySfx(AudioManager.Sfx.OpenBox);
                break;

            case ItemType.Magnet: // �� �ּ� ����
                GameManager.instance.ActivateMagnet(magnetRadius, magnetDuration); // �� ���� �ڼ� ON
                if (playSfx && GameManager.instance.isLive)
                    AudioManager.instance.PlaySfx(AudioManager.Sfx.OpenBox);      // �� ���� ����
                break; // �� �ּ� ����
        }

        StartCoroutine(DisableSoon());
    }

    IEnumerator DisableSoon()
    {
        yield return new WaitForSeconds(autoDisableDelay);
        gameObject.SetActive(false);
    }
}
