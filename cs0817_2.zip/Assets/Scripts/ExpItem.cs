using System.Collections;
using UnityEngine;

public class ExpItem : MonoBehaviour
{
    public int expValue = 1;
/*    public float magnetRadius = 0f;
    public float magnetSpeed = 5f;*/
    public float autoDisableDelay = 0.1f;

    [Header("Optional : BoxOpenAnim")]
    public Animator animator;
    public string openBoolName = "boxopen";   // [CHECK] Animator 파라미터명(Trigger)과 정확히 일치해야 함
    public string openClipName = "boxopen";   // [ADD] 애니메이션 클립 이름 (직접 재생용)
    public bool useTrigger = true;            // [ADD] 트리거 사용/직접 재생 전환 스위치

    private bool picked;

    Transform player;
    Rigidbody2D rb;
    Collider2D col;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        col = GetComponent<Collider2D>();

        // [FIX] Animator가 자식에 있을 가능성도 커버
        if (animator == null) animator = GetComponent<Animator>();
        if (animator == null) animator = GetComponentInChildren<Animator>(); // ← 추가

        if (col) col.isTrigger = true;
    }

    void OnEnable()
    {
        picked = false;

        if (player == null && GameManager.instance != null)
            player = GameManager.instance.player.transform;

        if (col) col.enabled = true;
    }

    public void Init(int value)
    {
        expValue = Mathf.Max(1, value);
        picked = false;
        if (col) col.enabled = true;
    }

/*    void Update()
    {
        if (magnetRadius > 0f && player != null)
        {
            float dist = Vector2.Distance(transform.position, player.position);
            if (dist < magnetRadius)
            {
                Vector3 dir = (player.position - transform.position).normalized;
                transform.position += dir * (magnetSpeed * Time.deltaTime);
            }
        }
    }*/

    void OnTriggerEnter2D(Collider2D other)
    {
        if (picked) return;
        if (!other.CompareTag("Player")) return;

        picked = true;
        if (col) col.enabled = false;

        GameManager.instance.AddExp(expValue);
        if (GameManager.instance.isLive)
            AudioManager.instance.PlaySfx(AudioManager.Sfx.GetItem);

        // 박스 애니 재생 분기 
        bool isBox = AnimatorLooksLikeBox(animator, openBoolName, openClipName); // [ADD] 박스 판단 보조

        if (animator != null && isBox)
        {
            if (useTrigger && HasTrigger(animator, openBoolName))              // [FIX] 트리거 경로 (정상 구성일 때)
            {
                AudioManager.instance.PlaySfx(AudioManager.Sfx.OpenBox);

                animator.ResetTrigger(openBoolName);                           // [ADD] 혹시 모를 잔여 트리거 초기화
                animator.SetTrigger(openBoolName);
            }
            else                                                               // [FIX] 트리거가 없거나 전이가 안 걸렸을 때 → 직접 재생
            {
                animator.Play(openClipName, 0, 0f);
            }

            // [FIX] 비활성화 딜레이를 클립 길이에 맞춤(설정값이 0.1f로 너무 짧으면 애니 안 보임)
            float delay = GetClipLength(animator, openClipName);
            if (delay <= 0f) delay = autoDisableDelay; // 클립 못 찾으면 기존 값 사용
            StartCoroutine(DisableAfterDelay(delay));
        }
        else
        {
            // 코인: 즉시 비활성화
            gameObject.SetActive(false);
        }
    }

    // [OVERLOAD] 지정한 대기 시간으로 비활성화
    IEnumerator DisableAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        gameObject.SetActive(false);
    }

    IEnumerator DisableAfterDelay()
    {
        yield return new WaitForSeconds(autoDisableDelay);
        gameObject.SetActive(false);
    }

    // [ADD] Animator에 특정 트리거 파라미터가 있는지 확인
    bool HasTrigger(Animator a, string triggerName)
    {
        if (a == null || string.IsNullOrEmpty(triggerName)) return false;
        foreach (var p in a.parameters)
            if (p.type == AnimatorControllerParameterType.Trigger && p.name == triggerName)
                return true;
        return false;
    }

    // [ADD] 박스 판단을 넉넉하게: 트리거나 클립이 있으면 박스로 간주
    bool AnimatorLooksLikeBox(Animator a, string triggerName, string clipName)
    {
        if (a == null) return false;
        if (HasTrigger(a, triggerName)) return true;
        var rc = a.runtimeAnimatorController;
        if (rc == null) return false;
        foreach (var c in rc.animationClips)
            if (c != null && c.name == clipName) return true;
        return false;
    }

    // [ADD] 지정한 클립 길이 찾기(없으면 0 반환)
    float GetClipLength(Animator a, string clipName)
    {
        if (a == null) return 0f;
        var rc = a.runtimeAnimatorController;
        if (rc == null) return 0f;
        foreach (var c in rc.animationClips)
            if (c != null && c.name == clipName)
                return c.length;
        return 0f;
    }
}



#region ver.1
/*public class ExpItem : MonoBehaviour
{
    public int expValue = 1;
    public float magnetRadius = 0f;
    public float magnetSpeed = 5f;
    public float autoDisableDelay = 0.1f;

    [Header("Optional : BoxOpenAnim")]
    public Animator animator;
    public string openBoolName = "boxopen";   // [CHECK] Animator 파라미터명과 정확히 일치해야 함
    private bool picked;

    Transform player;
    Rigidbody2D rb;
    Collider2D col;

    void Awake()
    {
        rb  = GetComponent<Rigidbody2D>();
        col = GetComponent<Collider2D>();

        if (animator == null) animator = GetComponent<Animator>(); // [KEEP] 인스펙터 미할당 시 자동 연결
        if (col) col.isTrigger = true;                              // [OPT] 아이템은 트리거로 고정
    }

    void OnEnable()
    {
        picked = false;

        if (player == null && GameManager.instance != null)
            player = GameManager.instance.player.transform;

        if (col) col.enabled = true;  // [FIX] 풀 재사용 시 콜라이더 복구
    }

    public void Init(int value)      // Enemy에서 값 주입
    {
        expValue = Mathf.Max(1, value);
        picked = false;

        if (col) col.enabled = true;  // [FIX] 풀 재사용 시 콜라이더 복구
    }

    public void InitRandom()         // (선택) 안 쓰면 삭제 OK
    {
        expValue = 1;
    }

    void Update()
    {
        if (magnetRadius > 0f && player != null)
        {
            float dist = Vector2.Distance(transform.position, player.position);
            if (dist < magnetRadius)
            {
                Vector3 dir = (player.position - transform.position).normalized;
                transform.position += dir * (magnetSpeed * Time.deltaTime);
            }
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (picked) return;
        if (!other.CompareTag("Player")) return;

        picked = true;
        if (col) col.enabled = false;  // [FIX] 중복 트리거 방지

        GameManager.instance.AddExp(expValue);

        if (GameManager.instance.isLive)
            AudioManager.instance.PlaySfx(AudioManager.Sfx.GetItem);

        // [FIX] 컨트롤러 이름 비교 대신, 트리거 존재 여부로 박스/코인 분기
        if (HasTrigger(animator, openBoolName))
        {
            animator.SetTrigger(openBoolName);   // "boxopen" 트리거 발동 (박스)
            StartCoroutine(DisableAfterDelay()); // 애니 조금 보여준 뒤 비활성화
        }
        else
        {
            gameObject.SetActive(false);         // 코인: 즉시 비활성화
        }
    }

    IEnumerator DisableAfterDelay()
    {
        yield return new WaitForSeconds(autoDisableDelay);
        gameObject.SetActive(false);
    }

    // [ADD] Animator에 특정 트리거 파라미터가 있는지 확인
    bool HasTrigger(Animator a, string triggerName)
    {
        if (a == null || string.IsNullOrEmpty(triggerName)) return false;
        foreach (var p in a.parameters)
        {
            if (p.type == AnimatorControllerParameterType.Trigger && p.name == triggerName)
                return true;
        }
        return false;
    }
}*/
#endregion