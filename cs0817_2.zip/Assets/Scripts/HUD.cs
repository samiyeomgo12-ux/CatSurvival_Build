using UnityEngine;
using System.Collections.Generic;
using UnityEngine.UI;
using System.Collections;
public class HUD : MonoBehaviour
{
  public enum InfoType { Exp, Level, Kill, Time, HP }
  public InfoType type;

    Text myText;
    Slider mySlider;

    private void Awake()
    {
        myText = GetComponent<Text>();
        mySlider = GetComponent<Slider>();
    }

    private void LateUpdate()
    {
        switch(type)
        {
            case InfoType.Exp:
                float curExp = GameManager.instance.exp;
                float maxExp = GameManager.instance.nextExp[Mathf.Min(GameManager.instance.level, GameManager.instance.nextExp.Length - 1)];
                mySlider.value = curExp / maxExp; 
                break;

            case InfoType.Level:
                myText.text = string.Format("Lv.{0:F0}", GameManager.instance.level); //{�������� �ε��� ����, ����������}
                
                break;

            case InfoType.Kill:
                myText.text = string.Format("{0:F0}", GameManager.instance.kill); //{�������� �ε��� ����, ����������}
                break;

            case InfoType.Time:
                float remainTime = GameManager.instance.maxGameTime - GameManager.instance.gameTime;
                int min = Mathf.FloorToInt(remainTime / 60); //��
                int sec = Mathf.FloorToInt(remainTime % 60); //��
                myText.text = string.Format("{0:D2}:{1:D2}",  min, sec);
                break;

            case InfoType.HP:
                float curPlayerHP = GameManager.instance.playerHP;
                float playerMaxHP = GameManager.instance.playerMaxHP;
                mySlider.value = curPlayerHP / playerMaxHP;
                break;

        }


    }
}
